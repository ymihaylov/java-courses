public enum ComputerType {
    DESKTOP,
    LAPTOP
}
